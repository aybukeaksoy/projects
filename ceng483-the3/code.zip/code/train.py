# Feel free to change / extend / adapt this source code as needed to complete the homework, based on its requirements.
# This code is given as a starting point.
#
# REFEFERENCES
# The code is partly adapted from pytorch tutorials, including https://pytorch.org/tutorials/beginner/blitz/cifar10_tutorial.html

# ---- hyper-parameters ----
# You should tune these hyper-parameters using:
# (i) your reasoning and observations, 
# (ii) by tuning it on the validation set, using the techniques discussed in class.
# You definitely can add more hyper-parameters here.

batch_size = 1
max_num_epoch = 100
#hps = {'lr':0.001}

# ---- options ----
DEVICE_ID = 'cpu' # set to 'cpu' for cpu, 'cuda' / 'cuda:0' or similar for gpu.
LOG_DIR = 'checkpoints'
VISUALIZE = False # set True to visualize input, prediction and the output from the last batch
LOAD_CHKPT = True
# --- imports ---
import torch
import os
import torch.nn as nn
import torch.optim as optim
import hw3utils
import numpy as np
torch.multiprocessing.set_start_method('spawn', force=True)
torch.manual_seed(8)
# ---- utility functions -----
def get_loaders(batch_size,device):
    data_root = ''
    train_set = hw3utils.HW3ImageFolder(root=os.path.join(data_root, 'ceng483-hw3-dataset/train'), device=device)
    train_loader = torch.utils.data.DataLoader(train_set, batch_size=batch_size, shuffle=True, num_workers=0)
    val_set = hw3utils.HW3ImageFolder(root=os.path.join(data_root, 'ceng483-hw3-dataset/val'), device=device)
    val_loader = torch.utils.data.DataLoader(val_set, batch_size=batch_size, shuffle=False, num_workers=0)
    # Note: you may later add test_loader to here.
    test_set = hw3utils.HW3ImageFolder(root=os.path.join(data_root, 'test'), device=device)
    test_loader = torch.utils.data.DataLoader(test_set, batch_size=batch_size, shuffle=False, num_workers=0)
    return train_loader, val_loader, test_loader

# ---- ConvNet -----
class Net(nn.Module):

    def __init__(self,num_of_conv_layers:int, num_of_kernels:int,batch_norm_layer:bool,tan_h:bool):
        super(Net, self).__init__()
        #self.conv1 = nn.Conv2d(1, 3, 5, padding=2)
        conv_layer=self.get_conv_layer(num_of_conv_layers,num_of_kernels,batch_norm_layer)
        last_layer=self.get_last_conv_layer(num_of_conv_layers,num_of_kernels,batch_norm_layer,tan_h)
        self.conv_layers=nn.Sequential(*conv_layer,*last_layer)
        print(self.conv_layers)

    def forward(self, grayscale_image):
        # apply your network's layers in the following lines:      
        x = self.conv_layers(grayscale_image)
        return x

    def get_conv_layer(self,num_of_conv_layers,num_of_kernels,batch_norm_layer):
        conv_layer=[]
        for i in range(num_of_conv_layers-1):
            input_channels = 1 if i == 0 else num_of_kernels
            output_channels = num_of_kernels
            conv_layer.append(nn.Conv2d(input_channels, output_channels, kernel_size=3,padding=1))
            if batch_norm_layer:
                conv_layer.append(nn.BatchNorm2d(output_channels))
            conv_layer.append(nn.ReLU())
        return conv_layer

    def get_last_conv_layer(self,num_of_conv_layers,num_of_kernels,batch_norm_layer,tan_h):
        last_layer=[]
        input_channels = 1 if num_of_conv_layers == 1 else num_of_kernels
        last_layer.append(nn.Conv2d(input_channels, 3, kernel_size=3,padding=1))
        if batch_norm_layer:
            last_layer.append(nn.BatchNorm2d(3))
        if tan_h:
            last_layer.append(nn.Tanh())
        return last_layer

class MarginLoss(nn.Module):
    def __init__(self, margin=24/255):
        super(MarginLoss, self).__init__()
        self.margin = margin

    def forward(self, x, y):
        absolute_difference = torch.abs(x - y)
        return torch.mean(torch.square(torch.max(absolute_difference - self.margin, torch.zeros_like(absolute_difference))))


hyperparameters = [[4, 16, 0.01,0,1]]


for param in hyperparameters:
    # ---- training code -----
    device = torch.device(DEVICE_ID)
    print('device: ' + str(device))
    net = Net(param[0],param[1],param[3],param[4]).to(device=device)
    #criterion = nn.MSELoss()
    criterion=MarginLoss()
    optimizer = optim.SGD(net.parameters(), param[2])
    train_loader, val_loader, test_loader = get_loaders(batch_size, device)


    print('training begins')
    print(param)
    avg_loss_list=[]
    avg_val_loss_list=[]
    for epoch in range(max_num_epoch):
        print(epoch)
        running_loss = 0.0  # training loss of the network
        for iteri, data in enumerate(train_loader, 0):
            inputs, targets = data  # inputs: low-resolution images, targets: high-resolution images.

            optimizer.zero_grad()  # zero the parameter gradients

            # do forward, backward, SGD step
            preds = net(inputs)
            loss = criterion(preds, targets)
            loss.backward()
            optimizer.step()

            # print loss
            running_loss += loss.item()
            print_n = 100  # feel free to change this constant
                # note: you most probably want to track the progress on the validation set as well (needs to be implemented)
            if (iteri == 0) and VISUALIZE:
                hw3utils.visualize_batch(inputs, preds, targets)
        avg_loss=running_loss / (iteri + 1)
        print('[avg network-loss: %.7f' % avg_loss)
        avg_loss_list.append(avg_loss)
        val_running_loss = 0.0  # training loss of the network
        for iterj, data in enumerate(val_loader, 0):
            inputs, targets = data  # inputs: low-resolution images, targets: high-resolution images.

            optimizer.zero_grad()  # zero the parameter gradients

            # do forward, backward, SGD step
            preds = net(inputs)
            loss = criterion(preds, targets)
            #loss.backward()
            #optimizer.step()

            val_running_loss += loss.item()

            if (iterj == 0) and VISUALIZE:
                hw3utils.visualize_batch(inputs, preds, targets)
        avg_val_loss=val_running_loss / (iterj+1)
        print('[avg network-val-loss: %.7f' % avg_val_loss)
        avg_val_loss_list.append(avg_val_loss)
        if((sum(avg_val_loss_list[-4:-1])/3 < avg_val_loss+0.0001 and epoch>2) or epoch==99):

            print('Saving the model, end of epoch %d' % (epoch + 1))
            if not os.path.exists(LOG_DIR):
                os.makedirs(LOG_DIR)
            torch.save(net.state_dict(), os.path.join(LOG_DIR, str(param[0])+'-'+str(param[1])+'-'+str(param[2])+'-'+'checkpoint.pt'))
            hw3utils.visualize_batch(inputs, preds, targets, os.path.join(LOG_DIR, str(param[0])+'-'+str(param[1])+'-'+str(param[2])+'-'+'.png'))
            save_folder = 'figures'
            os.makedirs(save_folder, exist_ok=True)
            # Save the figure to the folder
            save_path = os.path.join(save_folder, str(param[0])+'-'+str(param[1])+'-'+str(param[2])+'-'+'plot.png')
            title='Loss Over Epochs:'+"[Layers:"+str(param[0])+", Kernels:"+str(param[1]) +", Learning Rate:"+str(param[2])+"]"
            hw3utils.plot_figures(epoch+1, avg_loss_list, avg_val_loss_list, save_path,title)

            break
    print('Finished Training')

if LOAD_CHKPT:
    trained_net = torch.load(
        os.path.join(LOG_DIR, str(param[0]) + '-' + str(param[1]) + '-' + str(param[2]) + '-' + 'checkpoint.pt'),
        map_location=torch.device('cpu'))
    net.load_state_dict(trained_net)
    estimations = np.zeros((100, 3, 80, 80))
    for iterj, data in enumerate(test_loader, 0):
        inputs, _ = data  # inputs: low-resolution images, targets: high-resolution images.

        preds = net(inputs)

        # hw3utils.visualize_batch(inputs, preds, targets, os.path.join(LOG_DIR,
        # str(param[0]) + '-' + str(param[1]) + '-' + str(
        # param[2]) + '-' + 'margin-5.png'))

        preds = (preds + 1) * 255 / 2
        estimations[iterj] = preds.detach().numpy()

        if (iterj == 99):
            break
    estimations = np.transpose(estimations, (0, 2, 3, 1))
    np.save("estimations_test.npy", estimations)

