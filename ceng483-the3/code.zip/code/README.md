# IMAGE COLORIZATION

## File Descriptions

### `train.py`

This file includes the cnn implementation. The model can be created, trained and it's weights can be saved. Also estimations_test.npy is created here. 

### `hw3utils.py` and `utils.py`

The helper functions can be found under these files. Only hw3utils is changed and plot_figures function is added. 

#### Running the code:
You can change the data_root for the correct path to data and test sets
From the terminal (assuming that required libraries are installed):
python3 train.py
This will create a checkpoint.pt, plots under figures folder, and the image of predictions targets grayscale comparison. 
if LOAD_CHKPT İS True: 
estimations_test.npy and test_images.txt files will be created. 
If you want to run with another configuration, you can change the hyperparameters variable. It is hard coded. 
[num_of_convolution_layers:int, num_of_kernels:int, learning rate:float, batch_norm_layer:bool, tanh:bool]
default=[4,16,0,01,0,1]
If you want to change the loss function to MSE loss, you can change the criterion variable. It is hard coded. 
default=MarginLoss()

#### AUTHORS:
-Aybüke Aksoy
